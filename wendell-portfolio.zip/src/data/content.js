export const profile = {
  name: 'Wendell Dave Anciso',
  role: 'Backend Developer',
  location: 'Cabuyao, Laguna, Philippines',
  email: 'ancisowendell32@email.com',
  phone: '+63 921 279 2054',
  linkedin: 'https://www.linkedin.com/in/wendell-dave-anciso-074729225',
  github: 'https://github.com/Dev1ze32',
};

export const nav = [
  { label: 'Services', href: '#services' },
  { label: 'Approach', href: '#approach' },
  { label: 'Projects', href: '#projects' },
  { label: 'Skills', href: '#skills' },
  { label: 'Contact', href: '#contact' },
];

export const services = [
  {
    span: 'wide',
    title: 'From spreadsheet chaos to a single source of truth',
    body: 'Your team has outgrown what a spreadsheet can hold — duplicate tabs, broken formulas, and version-control-by-filename. I design and build a custom internal system around how your business actually runs, not around a generic template.',
    tag: 'CORE OFFER',
  },
  {
    span: 'tall',
    title: 'Backend REST APIs',
    body: 'APIs that connect the tools your business already uses and automate the handoffs generic SaaS can\u2019t.',
    tag: 'API DEVELOPMENT',
  },
  {
    span: 'square',
    title: 'Production deployment',
    body: 'Dockerized apps, Nginx reverse proxies, live Ubuntu servers. Not a prototype — a system your team runs on daily.',
    tag: 'DEVOPS',
  },
  {
    span: 'square',
    title: 'Workflow automation',
    body: 'Google Apps Script, Excel/Sheets pipelines, and bots for Discord, Viber, and Telegram that remove manual busywork.',
    tag: 'AUTOMATION',
  },
  {
    span: 'wide',
    title: 'AI chatbots & LLM workflows',
    body: 'Prompt-engineered chatbot flows and RAG-backed assistants for teams that want AI without hiring an ML team.',
    tag: 'AI / LLM',
  },
];

export const approachSteps = [
  {
    n: '01',
    title: 'Discovery call',
    body: 'We talk through the actual workflow — the spreadsheet, the bottleneck, who touches what and when. No generic requirements doc.',
  },
  {
    n: '02',
    title: 'System design',
    body: 'I map the data model and API surface to your real process, then walk it past you before writing a line of production code.',
  },
  {
    n: '03',
    title: 'Build & deploy',
    body: 'Containerized with Docker, served behind Nginx, live on your own Ubuntu server — not a local demo.',
  },
  {
    n: '04',
    title: 'Train & handoff',
    body: 'I sit with your team on the live system, fix what\u2019s awkward, and hand off something they actually know how to run.',
  },
];

export const skillGroups = [
  {
    label: 'Backend & APIs',
    items: ['Python (building & consuming REST APIs)', 'Postman'],
  },
  {
    label: 'Programming',
    items: ['Python', 'SQL'],
  },
  {
    label: 'Infrastructure & cloud',
    items: ['Docker', 'Nginx reverse proxies', 'Live Ubuntu server deployment', 'Git'],
  },
  {
    label: 'Automation & AI',
    items: ['Excel / Google Sheets automation', 'Google Apps Script', 'Prompt engineering', 'RAG', 'LangGraph', 'LLM APIs'],
  },
  {
    label: 'Hardware / IoT',
    items: ['Arduino', 'ESP microcontrollers', 'Raspberry Pi', 'Circuit design & prototyping'],
  },
];

export const projects = [
  {
    title: 'Pioneer Centralized Routing System API',
    summary:
      'A centralized routing database API built for a real manufacturing business, replacing a manual, spreadsheet-based tracking process with a system built around their own workflow.',
    points: [
      'Containerized with Docker; Nginx reverse proxy for a secure, production-grade rollout on a live Ubuntu server',
      'Pending-approval workflow, product revision tracking, and single-record Excel export — all requested directly by the client',
      'Owned through multiple live redeployments and user training sessions',
    ],
    stack: ['Python', 'Docker', 'Nginx', 'Ubuntu', 'REST API'],
    href: 'https://github.com/Dev1ze32/pioneer_centralized_routing_api',
    status: '200 OK',
    method: 'POST',
    endpoint: '/api/routing/entries',
  },
  {
    title: 'Faculty Scheduling System API',
    summary:
      'A backend REST API that streamlines academic scheduling and faculty management for a university department.',
    points: [
      'Lets professors digitally upload and process work declarations',
      'Resolves an administrative scheduling bottleneck that previously ran on manual paperwork',
    ],
    stack: ['Python', 'SQL', 'REST API'],
    href: 'https://github.com/Dev1ze32/schedule_system_api_v2',
    status: '200 OK',
    method: 'GET',
    endpoint: '/api/schedule/declarations',
  },
];

export const experience = [
  {
    role: 'Chatbot Builder Intern',
    org: 'SOFI AI Tech Solution Inc.',
    time: '1 month',
    points: [
      'Developed and refined AI chatbot workflows using prompt engineering to improve response accuracy and interaction flow',
      'Worked hands-on with LLMs, structuring prompts for consistent, reliable outputs',
      'Extracted and organized data into Excel spreadsheets to support automation pipelines and reporting',
      'Learned the end-to-end AI deployment process, from conversation design to iterating on output quality',
    ],
  },
];

export const education = {
  degree: 'Bachelor of Science in Computer Engineering',
  school: 'University of Cabuyao',
  detail: 'Expected graduation: 2027',
};

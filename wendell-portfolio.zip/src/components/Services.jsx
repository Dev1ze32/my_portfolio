import { useReveal } from '../hooks/useReveal';
import { services } from '../data/content';
import SectionHeading from './SectionHeading';

const spanClass = {
  wide: 'md:col-span-2',
  tall: 'md:row-span-2',
  square: '',
};

function Tile({ tile }) {
  const ref = useReveal();
  return (
    <article
      ref={ref}
      className={`reveal flex flex-col justify-between rounded-[var(--radius-md)] border border-[var(--color-rule)] bg-[var(--color-paper)] p-6 transition-colors duration-[var(--dur-base)] hover:border-[var(--color-accent)] sm:p-7 ${spanClass[tile.span]}`}
    >
      <div>
        <p className="font-mono-label mb-3 text-[var(--color-ink-faint)]">{tile.tag}</p>
        <h3 className="text-[length:var(--text-xl)] text-[var(--color-ink)]">{tile.title}</h3>
        <p className="mt-3 text-[length:var(--text-sm)] text-[var(--color-ink-muted)]">
          {tile.body}
        </p>
      </div>
    </article>
  );
}

export default function Services() {
  const headingRef = useReveal();
  return (
    <section id="services" className="py-[var(--space-3xl)]">
      <div className="mx-auto max-w-[var(--content-max)] px-[var(--page-gutter)]">
        <div ref={headingRef} className="reveal mb-14">
          <SectionHeading
            eyebrow="What I build"
            title="Software built around your workflow, not the other way around."
            body="Off-the-shelf SaaS asks your business to adapt. A custom internal system adapts to you."
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:auto-rows-[minmax(0,1fr)] md:grid-cols-4">
          {services.map((tile) => (
            <Tile key={tile.title} tile={tile} />
          ))}
        </div>
      </div>
    </section>
  );
}

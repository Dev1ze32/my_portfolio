import { useReveal } from '../hooks/useReveal';
import { skillGroups } from '../data/content';
import SectionHeading from './SectionHeading';

function Group({ group }) {
  const ref = useReveal();
  return (
    <div ref={ref} className="reveal border-t border-[var(--color-rule)] py-6 first:border-t-0">
      <h3 className="font-mono-label mb-3 text-[var(--color-ink)]">{group.label}</h3>
      <ul className="flex flex-wrap gap-2">
        {group.items.map((item) => (
          <li
            key={item}
            className="rounded-[var(--radius-xs)] border border-[var(--color-rule)] px-2.5 py-1 text-[length:var(--text-sm)] text-[var(--color-ink-2)]"
          >
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Skills() {
  const headingRef = useReveal();
  return (
    <section id="skills" className="py-[var(--space-3xl)]">
      <div className="mx-auto max-w-[var(--content-max)] px-[var(--page-gutter)]">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <div ref={headingRef} className="reveal">
            <SectionHeading
              eyebrow="Toolset"
              title="What's actually under the hood."
              body="No progress bars pretending to measure competence — just the stack I build with, grouped by what it's for."
            />
          </div>
          <div>
            {skillGroups.map((group) => (
              <Group key={group.label} group={group} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
